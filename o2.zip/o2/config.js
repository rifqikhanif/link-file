/**
   * Create By Dika Ardnt.
   * Contact Me on wa.me/6288292024190
   * Follow https://github.com/DikaArdnt
*/

const fs = require('fs')
const chalk = require('chalk')

// Website Api
global.APIs = {
	zenz: 'https://rifqi-api.herokuapp.com/images/logo.png',
}

// Apikey Website Api
global.APIKeys = {
	'https://zenzapi.xyz': '805a6c3fa9',
}

// Other
global.owner = ['6283838182659','6283838182659','6283838182659']
global.pemilik = ['6283838182659']
global.premium = ['6283838182659']
global.pengguna = 'Bowo'
global.botnma = 'Bebii-Bot'
global.harga = '10k'
global.atasreply = 'halo' //BUAT REPLAY DI ATAS NYA ADA TEXT
global.atasreply2 = 'love your self' //BUAT REPLAY DI ATAS NYA ADA TEXT KE 2
global.webreply = 'https://rifqi-api.herokuapp.com/images/logo.png' //URL DI ATAS REPLAY
global.webreply2 = 'https://rifqi-api.herokuapp.com/images/logo.png' //URL BUAT DI ATAS REPLAY KE 2
global.melcanz = 'Woo-ganz'
global.footer = 'call me kill' //FooterText Biar Di Bawah Nya Ada Text 
global.web = 'https://rifqi-api.herokuapp.com/images/logo.png' // Ubah Sama Lu Web Nya Bebas 
global.web2 = 'https://rifqi-api.herokuapp.com/images/logo.png' //Ubah Jga Bebas Sama lu 
global.ganti = 'ME FACE' //Edit Terserah Lu Mau Apa
global.ganti2 = '2'
global.accestken = 'Bowo'
global.ownernma = 'call me kill'
global.packname = 'Bebii-Bot'
global.author = 'Bowo'
global.sessionName = 'hisoka'
global.prefa = ['','!','.','🐦','🐤','🗿']
global.sp = '⭔'
global.mess = {
    success: '✓ S u c c e s s',
    admin: 'Fitur Khusus Admin Group!😞',
    botAdmin: 'Bot Harus Menjadi Admin Terlebih Dahulu!❌',
    owner: 'Fitur Khusus Owner Bot❌',
    group: 'Fitur Digunakan Hanya Untuk Group!❌',
    private: 'Fitur Digunakan Hanya Untuk Private Chat!❌',
    bot: 'Fitur Khusus Pengguna Nomor Bot❌',
    wait: 'W a i t . . . . ',
    endLimit: 'Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Jam 12',
}
global.limitawal = {
    premium: "Infinity",
    free: 100
}
global.thumb = fs.readFileSync('./media/Lycho.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
